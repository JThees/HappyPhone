chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log("📥 content.js received message:", msg);

  const smsInput = document.querySelector('[data-placeholder="New message"]');
  console.log("📌 Found smsInput:", smsInput);

  if (smsInput) {
    smsInput.textContent = msg.text; // test insertion
    sendResponse({ success: true });
  } else {
    sendResponse({ success: false, error: "SMS input not found" });
  }
});
