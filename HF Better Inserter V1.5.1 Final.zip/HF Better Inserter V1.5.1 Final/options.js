
document.getElementById("save").onclick = () => {
  const domain = document.getElementById("domain").value;
  const user = document.getElementById("user").value;
  const key = document.getElementById("key").value;
  chrome.storage.sync.set({
    hf_domain: domain,
    hf_user: user,
    hf_key: key
  }, () => {
    alert("Saved!");
  });
};
