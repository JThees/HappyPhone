# Changelog

## v1.4
- Added full theme support:
  - Light Mode (default)
  - Dark Mode (accessibility-focused)
  - HappyFox Mode (signature orange & cream aesthetic)
- UI auto-updates based on saved user preference

## v1.3
- Added "Copy to Clipboard" button
- Can be used in SMS, chat, or any text-based tool
- Preserves editable preview box as source

## v1.2
- Improved button layout and usability
- Cleaned up toggle logic for Edit Mode and button state switching

## v1.1
- Added settings UI with:
  - API Key
  - Username
  - Domain
- Settings stored via `chrome.storage.sync`
- Toggle panel visibility with Settings link

## v1.0
- Load and insert multiple canned actions
- Drag-and-drop to reorder
- Single-click insertion into HappyFox ticket editor
