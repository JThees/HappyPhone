# HappyFox Multi-Canned Action Inserter

A Chrome extension to enhance HappyFox's canned actions system.

**Features:**

- Select and insert multiple canned responses into tickets
- Edit the final response preview before inserting
- Copy responses to clipboard for use in SMS, chat, email, etc.
- Theme support: Light Mode, Dark Mode, and HappyFox Mode
- Saves API key, username, and domain in extension settings
- Works directly with HappyFox ticket editor, with clipboard fallback for other interfaces

**How to Use:**
1. Click the extension icon
2. Select one or more canned responses
3. Toggle "Editable" if you want to customize the output
4. Click "Insert" or "Copy" depending on your use case
5. Customize your theme in the Settings panel (gear icon)

---

## Requirements

- HappyFox API access with Canned Actions
- Your HappyFox domain and credentials
