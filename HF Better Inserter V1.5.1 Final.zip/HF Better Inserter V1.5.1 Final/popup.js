// =================================================================================
// popup.js (v1.5) – use innerHTML for preview, innerText for copy/insert
// =================================================================================

// 1) Helper: extract only the <body> contents of the API’s `html` field
function extractBody(html) {
  if (!html || typeof html !== "string") return "";
  const match = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  return match ? match[1].trim() : html.trim();
}

// 2) Whenever items get (un)selected, build a single HTML string & show it in the preview
function updatePreview() {
  const previewBox = document.getElementById("preview-content");
  if (!previewBox) return;

  // ‘selected’ holds raw HTML snippets (extracted from item.html or item.text).
  // We join them with two newlines between each block, then render as HTML.
  const combined = selected.join("\n\n").trim();
  previewBox.innerHTML = combined;
}

// ─────────────────────────────────────────────────────────────────────────────────
// 3) Globals
let selected = [];
let allResponses = [];

// 4) Grouping helper (no changes here)
function groupByPrefix(items) {
  const groups = {};
  items.forEach(item => {
    const parts = item.name.split(" - ");
    const group = parts.length > 1 ? parts[0].trim() : "Misc";
    if (!groups[group]) groups[group] = [];
    groups[group].push(item);
  });
  return groups;
}

// 5) Render the list of canned‐actions (using HTML for the little “preview” inside each item)
function renderList(filtered = null) {
  const list = document.getElementById("response-list");
  list.innerHTML = "";

  const grouped = groupByPrefix(filtered || allResponses);
  Object.entries(grouped).forEach(([groupName, items]) => {
    // Build the group header (+ emoji to expand/collapse)
    const groupHeader = document.createElement("div");
    groupHeader.className = "group-header";
    groupHeader.style.display = "flex";
    groupHeader.style.justifyContent = "space-between";
    groupHeader.style.alignItems = "center";
    groupHeader.style.marginTop = "10px";
    groupHeader.style.fontWeight = "bold";
    groupHeader.style.color = "#007bff";

    const groupLabel = document.createElement("span");
    groupLabel.textContent = `${groupName} (${items.length})`;

    const groupToggle = document.createElement("button");
    groupToggle.className = "group-toggle";
    groupToggle.textContent = "+";
    groupToggle.title = "Expand group";
    groupToggle.style.cursor = "pointer";
    groupToggle.style.background = "none";
    groupToggle.style.border = "none";
    groupToggle.style.fontSize = "1em";
    groupToggle.style.padding = "0";
    groupToggle.style.marginLeft = "10px";

    const groupContainer = document.createElement("div");
    groupContainer.style.marginLeft = "10px";
    groupContainer.style.display = "none";

    groupToggle.addEventListener("click", e => {
      e.stopPropagation();
      const isOpen = groupContainer.style.display === "block";
      const nowOpen = !isOpen;
      groupContainer.style.display = nowOpen ? "block" : "none";
      groupToggle.textContent = nowOpen ? "-" : "+";
      groupToggle.title = isOpen ? "Expand group" : "Collapse group";
    });

    groupHeader.appendChild(groupLabel);
    groupHeader.appendChild(groupToggle);
    list.appendChild(groupHeader);
    list.appendChild(groupContainer);

    // Now loop through each item in this group
    items.forEach(item => {
      const wrapper = document.createElement("div");
      wrapper.className = "response-item";
      wrapper.setAttribute("draggable", true);
      wrapper.removeAttribute("style");

      // Title row: name + preview toggle button
      const title = document.createElement("div");
      title.style.display = "flex";
      title.style.justifyContent = "space-between";
      title.style.alignItems = "center";

      const label = document.createElement("span");
      label.textContent = item.name;

      const previewToggle = document.createElement("button");
      previewToggle.textContent = "+";
      previewToggle.className = "preview-toggle";
      previewToggle.title = "Show preview";
      previewToggle.style.cursor = "pointer";
      previewToggle.style.background = "none";
      previewToggle.style.border = "none";
      previewToggle.style.fontSize = "1em";

      title.appendChild(label);
      title.appendChild(previewToggle);
      wrapper.appendChild(title);

      // The hidden preview DIV that shows the actual HTML of this canned action
      const preview = document.createElement("div");
      preview.className = "response-preview";
      preview.innerHTML = extractBody(item.html || item.text);
      preview.style.display = "none";
      preview.style.whiteSpace = "pre-wrap";
      preview.style.marginTop = "4px";
      preview.style.padding = "6px";
      preview.style.borderLeft = "2px solid #007bff";
      preview.style.background = "#fff";

      wrapper.appendChild(preview);

      previewToggle.onclick = e => {
        e.stopPropagation();
        const visible = preview.style.display === "block";
        preview.style.display = visible ? "none" : "block";
        previewToggle.textContent = visible ? "+" : "-";
        previewToggle.title = visible ? "Show preview" : "Hide preview";
      };

      // When you click the item itself, toggle selection in `selected[]`
      wrapper.onclick = () => {
        const content = extractBody(item.html || item.text || "");
        if (!wrapper.classList.contains("selected")) {
          selected.push(content);
          wrapper.classList.add("selected");
        } else {
          const index = selected.indexOf(content);
          if (index !== -1) selected.splice(index, 1);
          wrapper.classList.remove("selected");
        }
        updatePreview();
      };

      // Drag/drop for manual reordering (no changes here)
      wrapper.addEventListener("dragstart", e => {
        e.dataTransfer.setData("text/plain", item.text);
        e.dataTransfer.effectAllowed = "move";
        wrapper.classList.add("dragging");
      });
      wrapper.addEventListener("dragend", () => {
        wrapper.classList.remove("dragging");
      });
      wrapper.addEventListener("dragover", e => {
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
      });
      wrapper.addEventListener("drop", e => {
        e.preventDefault();
        const draggedText = e.dataTransfer.getData("text/plain");
        const fromIndex = selected.indexOf(draggedText);
        const toIndex = selected.indexOf(extractBody(item.html || item.text || ""));
        if (fromIndex !== -1 && toIndex !== -1 && fromIndex !== toIndex) {
          const [moved] = selected.splice(fromIndex, 1);
          selected.splice(toIndex, 0, moved);
        }
        updatePreview();
      });

      groupContainer.appendChild(wrapper);
    });
  });
}

// 6) Fetch from HappyFox (no change—just pull `data.results`)
function fetchResponses(domain, username, apiKey) {
  fetch(`https://${domain}/api/v2/canned-actions/?limit=50`, {
    headers: {
      'Authorization': 'Basic ' + btoa(username + ':' + apiKey)
    }
  })
  .then(res => res.json())
  .then(data => {
    allResponses = data.results;
    renderList();
  });
}

// 7) “Insert into Ticket” now uses a temporary DIV to grab .innerText

document.getElementById("insert-btn").onclick = () => {
  const previewBox = document.getElementById("preview-content");
  if (!previewBox) return;

  const htmlToInsert = previewBox.innerHTML.trim();

  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (html) => {
        const editor = document.querySelector(".ProseMirror");
        if (editor) {
          editor.focus();
          document.execCommand('insertHTML', false, html);
        }
      },
      args: [htmlToInsert]
    });
  });
};

// 8) “Clear” just wipes selection and repaints
document.getElementById("clear-btn").onclick = () => {
  selected = [];
  renderList();
  updatePreview();
};

// 9) Filtering/search (unchanged)
document.getElementById("search-box").addEventListener("input", e => {
  const query = e.target.value.toLowerCase();
  const filtered = allResponses.filter(r => r.name.toLowerCase().includes(query));
  renderList(filtered);
});

// 10) Load stored creds → fetchResponses (unchanged)
console.log("🛠 Checking for stored credentials...");
chrome.storage.sync.get(["apiKey", "userName", "domain"], creds => {
  console.log("🛠 Retrieved credentials:", creds);
  if (creds.domain && creds.userName && creds.apiKey) {
    console.log("✅ Credentials found, fetching responses...");
    fetchResponses(creds.domain, creds.userName, creds.apiKey);
  } else {
    console.warn("⚠️ Missing credentials. Opening settings panel.");
    const settingsPanel = document.getElementById("settings-panel");
    if (settingsPanel) {
      settingsPanel.style.display = "block";
    }
  }
});

console.log("Popup script loaded.");

// 11) Settings‐panel toggle (unchanged)
window.addEventListener("load", function () {
  console.log("Window loaded.");
  const btn = document.getElementById("settings-button");
  const panel = document.getElementById("settings-panel");
  const apiKeyInput = document.getElementById("apiKeyInput");
  const userNameInput = document.getElementById("userNameInput");
  const domainInput = document.getElementById("domainInput");
  const themeSelect = document.getElementById("themeSelect");

  // Load saved settings into inputs and apply theme
  chrome.storage.sync.get(["apiKey", "userName", "domain", "theme"], creds => {
    if (creds.apiKey)      apiKeyInput.value = creds.apiKey;
    if (creds.userName)    userNameInput.value = creds.userName;
    if (creds.domain)      domainInput.value = creds.domain;
    if (creds.theme) {
      themeSelect.value = creds.theme;
      applyTheme(creds.theme);
    }
  });
  const saveButton = document.getElementById("saveSettings");
  const previewContent = document.getElementById("preview-content");
  const toggleEditBtn = document.getElementById("toggle-edit-btn");

  // Settings panel toggle
  if (btn && panel) {
    btn.addEventListener("click", () => {
      panel.style.display = panel.style.display === "none" ? "block" : "none";
      console.log("Panel toggled. Now:", panel.style.display);
    });
  }

  // Save button logic
  if (saveButton) {
    saveButton.addEventListener("click", () => {
      const settings = {
        apiKey: apiKeyInput.value,
        userName: userNameInput.value,
        domain: domainInput.value,
        theme: themeSelect.value
      };
      chrome.storage.sync.set(settings, () => {
        console.log("Saved settings:", settings);
        alert("Settings saved.");
      });
    });
  }

  // Theme‐switcher (unchanged)
  if (themeSelect) {
    themeSelect.addEventListener("change", () => {
      applyTheme(themeSelect.value);
    });
  }

  // “Edit” toggle (unchanged)
  if (toggleEditBtn && previewContent) {
    toggleEditBtn.addEventListener("click", () => {
      const formatToolbar = document.getElementById("format-toolbar");
      const isEditing = previewContent.getAttribute("contenteditable") === "true";
      if (!isEditing) {
        // Enter edit mode
        previewContent.setAttribute("contenteditable", "true");
        previewContent.style.backgroundColor = "#ffffff";
        formatToolbar.style.display = "flex";
        toggleEditBtn.textContent = "Save";
        toggleEditBtn.style.backgroundColor = "#28a745";
        toggleEditBtn.style.color = "white";
      } else {
        // Exit edit mode
        previewContent.setAttribute("contenteditable", "false");
        previewContent.style.backgroundColor = "";
        formatToolbar.style.display = "none";
        toggleEditBtn.textContent = "Edit";
        toggleEditBtn.style.backgroundColor = "#dc3545";
        toggleEditBtn.style.color = "white";
      }
});
  }
});

// 12) Copy button: also use innerText instead of regex

document.getElementById("copy-btn").onclick = () => {
  const previewBox = document.getElementById("preview-content");
  if (!previewBox) return;

  const html = previewBox.innerHTML.trim();

  navigator.clipboard.writeText(html)
    .then(() => {
      console.log("📋 Copied to clipboard");
      const btn = document.getElementById("copy-btn");
      btn.textContent = "Copied!";
      btn.disabled = true;
      setTimeout(() => {
        btn.textContent = "Copy";
        btn.disabled = false;
      }, 1500);
    })
    .catch(err => {
      console.error("❌ Failed to copy", err);
    });
};

// 13) applyTheme (unchanged)
function applyTheme(theme) {
  document.body.classList.remove("light-mode", "dark-mode", "happyfox-mode");
  if (theme === "dark") {
    document.body.classList.add("dark-mode");
  } else if (theme === "happyfox") {
    document.body.classList.add("happyfox-mode");
  } else {
    document.body.classList.add("light-mode");
  }
}


// Formatting button handlers – ensure these are always active
const boldBtn = document.getElementById("bold-btn");
const italicBtn = document.getElementById("italic-btn");
const underlineBtn = document.getElementById("underline-btn");
const linkBtn = document.getElementById("link-btn");
const bulletBtn = document.getElementById("bullet-btn");
const fontSelect = document.getElementById("font-select");
const fontSizeSelect = document.getElementById("font-size-select");

if (boldBtn) boldBtn.addEventListener("click", () => document.execCommand("bold", false, null));
if (italicBtn) italicBtn.addEventListener("click", () => document.execCommand("italic", false, null));
if (underlineBtn) underlineBtn.addEventListener("click", () => document.execCommand("underline", false, null));

if (linkBtn) {
  linkBtn.addEventListener("click", () => {
    const url = prompt("Enter URL:", "https://");
    if (url) document.execCommand("createLink", false, url);
  });
}

if (bulletBtn) bulletBtn.addEventListener("click", () => document.execCommand("insertUnorderedList", false, null));

if (fontSelect) {
  fontSelect.addEventListener("change", () => {
    const fontName = fontSelect.value;
    document.execCommand("fontName", false, fontName);
  });
}

if (fontSizeSelect) {
  fontSizeSelect.addEventListener("change", () => {
    const fontSize = fontSizeSelect.value;
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    const span = document.createElement("span");
    span.style.fontSize = fontSize;
    span.appendChild(range.extractContents());
    range.deleteContents();
    range.insertNode(span);
  });
}
